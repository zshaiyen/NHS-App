#
# Flask passenger script for Production WSGI only
#
from app import app as application
